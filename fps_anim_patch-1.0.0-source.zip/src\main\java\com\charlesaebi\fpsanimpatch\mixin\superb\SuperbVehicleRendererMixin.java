package com.charlesaebi.fpsanimpatch.mixin.superb;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.atsuishio.superbwarfare.client.renderer.entity.VehicleRenderer", remap = false)
public abstract class SuperbVehicleRendererMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$distanceCull(Entity vehicle, Frustum camera, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
        if (!FpsAnimPatchConfig.enabled()
                || !FpsAnimPatchConfig.SUPERB_ENABLE.get()
                || !FpsAnimPatchConfig.SUPERB_VEHICLE_CULLING.get()) {
            return;
        }
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || vehicle == null) {
            return;
        }
        int maxDistance = FpsAnimPatchConfig.GENERAL_MAX_DISTANCE_VEHICLES.get();
        if (maxDistance > 0 && player.distanceToSqr(vehicle) > (double) maxDistance * maxDistance) {
            cir.setReturnValue(false);
        }
    }
}
