package com.charlesaebi.fpsanimpatch.mixin.superb;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import com.charlesaebi.fpsanimpatch.util.Reflector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "com.atsuishio.superbwarfare.client.overlay.VehicleHudOverlay", remap = false)
public abstract class SuperbVehicleHudOverlayMixin {
    @Inject(method = "renderWeaponInfo", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$hideReloadRing(GuiGraphics guiGraphics, Object vehicle, int width, int height, CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled()
                || !FpsAnimPatchConfig.SUPERB_ENABLE.get()
                || !FpsAnimPatchConfig.SUPERB_HIDE_RELOAD_OVERLAY.get()) {
            return;
        }

        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || vehicle == null) {
            return;
        }

        try {
            Object seatIndexValue = Reflector.invokeCompatible(vehicle, "getSeatIndex", player);
            if (!(seatIndexValue instanceof Integer seatIndex) || seatIndex < 0) {
                return;
            }
            Object weaponIndexValue = Reflector.invokeCompatible(vehicle, "getWeaponIndex", seatIndex);
            if (!(weaponIndexValue instanceof Integer weaponIndex) || weaponIndex < 0) {
                return;
            }
            Object gunData = Reflector.invokeCompatible(vehicle, "getGunData", seatIndex, weaponIndex);
            if (gunData != null && Boolean.TRUE.equals(Reflector.invokeCompatible(gunData, "reloading"))) {
                ci.cancel();
            }
        } catch (ReflectiveOperationException ignored) {
        }
    }
}
