package com.charlesaebi.fpsanimpatch.mixin.tacz;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "com.tacz.guns.client.gameplay.LocalPlayerDraw", remap = false)
public abstract class TaczLocalPlayerDrawMixin {
    @Inject(method = "doDraw", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$skipDrawDelay(ItemStack currentItem, long putAwayTime, CallbackInfo ci) {
        if (FpsAnimPatchConfig.enabled() && FpsAnimPatchConfig.TACZ_ENABLE.get() && FpsAnimPatchConfig.TACZ_INSTANT_DRAW.get()) {
            ci.cancel();
        }
    }

    @Inject(method = "doPutAway", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$skipPutAway(ItemStack lastItem, long putAwayTime, CallbackInfo ci) {
        if (FpsAnimPatchConfig.enabled() && FpsAnimPatchConfig.TACZ_ENABLE.get() && FpsAnimPatchConfig.TACZ_INSTANT_DRAW.get()) {
            ci.cancel();
        }
    }
}
