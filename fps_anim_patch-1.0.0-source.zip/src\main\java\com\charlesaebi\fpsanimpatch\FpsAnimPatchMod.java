package com.charlesaebi.fpsanimpatch;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(FpsAnimPatchMod.MOD_ID)
public final class FpsAnimPatchMod {
    public static final String MOD_ID = "fps_anim_patch";
    public static final Logger LOGGER = LogUtils.getLogger();

    public FpsAnimPatchMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, FpsAnimPatchConfig.SPEC, "fps_anim_patch.toml");
        LOGGER.info("[fps_anim_patch] Client animation patch bootstrap loaded.");
    }
}
