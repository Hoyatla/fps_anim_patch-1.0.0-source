package com.charlesaebi.fpsanimpatch.mixin.tacz;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import com.charlesaebi.fpsanimpatch.FpsAnimPatchMod;
import com.charlesaebi.fpsanimpatch.util.Reflector;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "com.tacz.guns.client.renderer.item.AnimateGeoItemRenderer", remap = false)
public abstract class TaczAnimateGeoItemRendererMixin {
    @Inject(method = "tryInit", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$instantDraw(ItemStack stack, Player player, float partialTick, CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled() || !FpsAnimPatchConfig.TACZ_ENABLE.get() || !FpsAnimPatchConfig.TACZ_INSTANT_DRAW.get()) {
            return;
        }
        try {
            Object stateMachine = Reflector.invokeCompatible(this, "getStateMachine", stack);
            if (stateMachine == null) {
                ci.cancel();
                return;
            }
            Object initialized = Reflector.invokeCompatible(stateMachine, "isInitialized");
            if (initialized instanceof Boolean && (Boolean) initialized) {
                Reflector.invokeCompatible(stateMachine, "exit");
            }
            Object context = Reflector.invokeCompatible(this, "initContext", stack, player, partialTick);
            if (context != null) {
                Reflector.invokeCompatible(stateMachine, "setContext", context);
                Reflector.invokeCompatible(stateMachine, "initialize");
            }
            ci.cancel();
        } catch (ReflectiveOperationException exception) {
            if (FpsAnimPatchConfig.GENERAL_DEBUG_LOG.get()) {
                FpsAnimPatchMod.LOGGER.info("[fps_anim_patch] TACZ instant draw fallback failed: {}", exception.getMessage());
            }
        }
    }

    @Inject(method = "tryExit", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$instantHolster(ItemStack stack, long putAwayTime, CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled() || !FpsAnimPatchConfig.TACZ_ENABLE.get() || !FpsAnimPatchConfig.TACZ_INSTANT_DRAW.get()) {
            return;
        }
        try {
            Object stateMachine = Reflector.invokeCompatible(this, "getStateMachine", stack);
            if (stateMachine != null) {
                Object initialized = Reflector.invokeCompatible(stateMachine, "isInitialized");
                if (initialized instanceof Boolean && (Boolean) initialized) {
                    Reflector.invokeCompatible(stateMachine, "exit");
                }
                Reflector.invokeCompatible(stateMachine, "setExitingTime", 0L);
            }
            ci.cancel();
        } catch (ReflectiveOperationException exception) {
            if (FpsAnimPatchConfig.GENERAL_DEBUG_LOG.get()) {
                FpsAnimPatchMod.LOGGER.info("[fps_anim_patch] TACZ instant holster fallback failed: {}", exception.getMessage());
            }
        }
    }
}
