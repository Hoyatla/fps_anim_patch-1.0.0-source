package com.charlesaebi.fpsanimpatch.mixin.tacz;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "com.tacz.guns.client.gameplay.LocalPlayerReload", remap = false)
public abstract class TaczLocalPlayerReloadMixin {
    @Inject(method = "doReload", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$cancelReloadVisuals(CallbackInfo ci) {
        if (FpsAnimPatchConfig.enabled()
                && FpsAnimPatchConfig.TACZ_ENABLE.get()
                && FpsAnimPatchConfig.TACZ_CANCEL_RELOAD_ANIMATION.get()) {
            ci.cancel();
        }
    }
}
