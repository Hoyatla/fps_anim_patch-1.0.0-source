package com.charlesaebi.fpsanimpatch.mixin.superb;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import com.charlesaebi.fpsanimpatch.client.FpsAnimPatchClientEvents;
import com.charlesaebi.fpsanimpatch.util.Reflector;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ViewportEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "com.atsuishio.superbwarfare.event.ClientEventHandler", remap = false)
public abstract class SuperbClientEventHandlerMixin {
    @Inject(method = "resetGunStatus", at = @At("TAIL"))
    private static void fpsAnimPatch$flattenDraw(CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled() || !FpsAnimPatchConfig.SUPERB_ENABLE.get() || !FpsAnimPatchConfig.SUPERB_INSTANT_DRAW.get()) {
            return;
        }
        try {
            Reflector.setStaticField("com.atsuishio.superbwarfare.event.ClientEventHandler", "drawTime", 0.08D);
        } catch (ReflectiveOperationException ignored) {
        }
    }

    @Inject(method = "handleReloadShake", at = @At("HEAD"), cancellable = true)
    private static void fpsAnimPatch$cancelReloadShake(double boneRotX, double boneRotY, double boneRotZ, CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled()
                || !FpsAnimPatchConfig.SUPERB_ENABLE.get()
                || !FpsAnimPatchConfig.SUPERB_CANCEL_RELOAD_ANIMATION.get()) {
            return;
        }
        try {
            Reflector.setStaticField("com.atsuishio.superbwarfare.event.ClientEventHandler", "cameraRot", new double[]{0.0D, 0.0D, 0.0D});
        } catch (ReflectiveOperationException ignored) {
        }
        ci.cancel();
    }

    @Inject(method = "handleWeaponFire", at = @At("HEAD"), cancellable = true)
    private static void fpsAnimPatch$throttleWeaponFire(ViewportEvent.ComputeCameraAngles event, Object entity, CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled()
                || !FpsAnimPatchConfig.SUPERB_ENABLE.get()
                || !FpsAnimPatchConfig.SUPERB_OPTIMIZE_SHOOT.get()) {
            return;
        }
        if (FpsAnimPatchClientEvents.shouldThrottleWeaponUpdates()) {
            ci.cancel();
        }
    }

    @Inject(method = "handleGunRecoil", at = @At("HEAD"), cancellable = true)
    private static void fpsAnimPatch$throttleGunRecoil(CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled()
                || !FpsAnimPatchConfig.SUPERB_ENABLE.get()
                || !FpsAnimPatchConfig.SUPERB_OPTIMIZE_SHOOT.get()) {
            return;
        }
        if (FpsAnimPatchClientEvents.shouldThrottleWeaponUpdates()) {
            ci.cancel();
        }
    }

    @Inject(method = "computeCameraAngles", at = @At("TAIL"))
    private static void fpsAnimPatch$reduceShake(ViewportEvent.ComputeCameraAngles event, CallbackInfo ci) {
        if (!FpsAnimPatchConfig.enabled()
                || !FpsAnimPatchConfig.SUPERB_ENABLE.get()
                || !FpsAnimPatchConfig.SUPERB_REDUCE_SCREEN_SHAKE.get()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        event.setPitch((float) (mc.gameRenderer.getMainCamera().getXRot() + (event.getPitch() - mc.gameRenderer.getMainCamera().getXRot()) * 0.55F));
        event.setYaw((float) (mc.gameRenderer.getMainCamera().getYRot() + (event.getYaw() - mc.gameRenderer.getMainCamera().getYRot()) * 0.55F));
        event.setRoll(event.getRoll() * 0.5F);
    }
}
