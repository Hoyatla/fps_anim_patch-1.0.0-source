package com.charlesaebi.fpsanimpatch.client;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import com.charlesaebi.fpsanimpatch.FpsAnimPatchMod;
import com.charlesaebi.fpsanimpatch.util.Reflector;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FpsAnimPatchMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class FpsAnimPatchClientEvents {
    private static boolean loggedCompat;

    private FpsAnimPatchClientEvents() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !FpsAnimPatchConfig.enabled()) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (!loggedCompat && mc.level != null) {
            loggedCompat = true;
            debug("Detected TACZ=" + ModList.get().isLoaded("tacz") + ", SuperbWarfare=" + ModList.get().isLoaded("superbwarfare"));
        }

        if (mc.level == null) {
            return;
        }

        long tick = mc.level.getGameTime();
        if (tick % 20L == 0L) {
            applyExternalCompat();
        }

        if (ModList.get().isLoaded("superbwarfare") && FpsAnimPatchConfig.SUPERB_ENABLE.get()) {
            clampSuperbDraw();
        }

        if (ModList.get().isLoaded("tacz") && FpsAnimPatchConfig.TACZ_ENABLE.get()) {
            clearTaczCrosshairSuppression(mc.player);
        }
    }

    @SubscribeEvent
    public static void onOverlayPost(RenderGuiOverlayEvent.Post event) {
        if (!FpsAnimPatchConfig.enabled()) {
            return;
        }
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.CROSSHAIR.id())) {
            return;
        }
        if (shouldRenderTaczReloadCrosshair()) {
            drawMinimalCrosshair(event.getGuiGraphics(), event.getWindow().getGuiScaledWidth(), event.getWindow().getGuiScaledHeight());
        }
    }

    private static void applyExternalCompat() {
        applyTaczCompat();
        applySuperbCompat();
    }

    private static void applyTaczCompat() {
        if (!ModList.get().isLoaded("tacz") || !FpsAnimPatchConfig.TACZ_ENABLE.get()) {
            return;
        }
        try {
            if (FpsAnimPatchConfig.TACZ_FORCE_LOW_DETAIL.get()) {
                Reflector.setForgeConfigValue("com.tacz.guns.config.client.RenderConfig", "GUN_LOD_RENDER_DISTANCE", 0);
            }
            if (FpsAnimPatchConfig.TACZ_OPTIMIZE_SHOOT.get()) {
                Reflector.setForgeConfigValue("com.tacz.guns.config.client.RenderConfig", "FIRST_PERSON_BULLET_TRACER_ENABLE", false);
                Reflector.setForgeConfigValue("com.tacz.guns.config.client.RenderConfig", "DISABLE_MOVEMENT_ATTRIBUTE_FOV", true);
            }
            if (FpsAnimPatchConfig.TACZ_REDUCE_LASER_EFFECTS.get()) {
                Reflector.setForgeConfigValue("com.tacz.guns.config.client.RenderConfig", "ENABLE_LASER_FADE_OUT", false);
            }
        } catch (ReflectiveOperationException exception) {
            debug("TACZ config reflection failed: " + exception.getMessage());
        }
    }

    private static void applySuperbCompat() {
        if (!ModList.get().isLoaded("superbwarfare") || !FpsAnimPatchConfig.SUPERB_ENABLE.get()) {
            return;
        }
        try {
            if (FpsAnimPatchConfig.SUPERB_FORCE_GUN_LOD.get()) {
                Reflector.setForgeConfigValue("com.atsuishio.superbwarfare.config.client.DisplayConfig", "ENABLE_GUN_LOD", true);
            }
            if (FpsAnimPatchConfig.SUPERB_INSTANT_DRAW.get()) {
                Reflector.setForgeConfigValue("com.atsuishio.superbwarfare.config.client.DisplayConfig", "CAMERA_ROTATE", false);
            }
            if (FpsAnimPatchConfig.SUPERB_REDUCE_SCREEN_SHAKE.get()) {
                Reflector.setForgeConfigValue("com.atsuishio.superbwarfare.config.client.DisplayConfig", "WEAPON_SCREEN_SHAKE", 20);
                Reflector.setForgeConfigValue("com.atsuishio.superbwarfare.config.client.DisplayConfig", "EXPLOSION_SCREEN_SHAKE", 45);
                Reflector.setForgeConfigValue("com.atsuishio.superbwarfare.config.client.DisplayConfig", "SHOCK_SCREEN_SHAKE", 30);
            }
        } catch (ReflectiveOperationException exception) {
            debug("SuperbWarfare config reflection failed: " + exception.getMessage());
        }
    }

    private static void clampSuperbDraw() {
        try {
            Object raw = Reflector.getStaticField("com.atsuishio.superbwarfare.event.ClientEventHandler", "drawTime");
            if (raw instanceof Double value && value > 0.08D) {
                Reflector.setStaticField("com.atsuishio.superbwarfare.event.ClientEventHandler", "drawTime", 0.08D);
            }
        } catch (ReflectiveOperationException exception) {
            debug("Superb draw clamp failed: " + exception.getMessage());
        }
    }

    private static void clearTaczCrosshairSuppression(LocalPlayer player) {
        if (player == null || !FpsAnimPatchConfig.TACZ_HIDE_RELOAD_OVERLAY.get()) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (stack.isEmpty()) {
            return;
        }
        try {
            Object renderer = IClientItemExtensions.of(stack.getItem()).getCustomRenderer();
            if (renderer == null || !"com.tacz.guns.client.renderer.item.AnimateGeoItemRenderer".equals(renderer.getClass().getName())) {
                return;
            }
            Object stateMachine = Reflector.invokeCompatible(renderer, "getStateMachine", stack);
            if (stateMachine == null) {
                return;
            }
            Object context = Reflector.invokeCompatible(stateMachine, "getContext");
            if (context != null) {
                Reflector.invokeCompatible(context, "setShouldHideCrossHair", false);
            }
        } catch (ReflectiveOperationException exception) {
            debug("TACZ crosshair suppression clear failed: " + exception.getMessage());
        }
    }

    private static boolean shouldRenderTaczReloadCrosshair() {
        if (!ModList.get().isLoaded("tacz")
                || !FpsAnimPatchConfig.TACZ_ENABLE.get()
                || !FpsAnimPatchConfig.TACZ_HIDE_RELOAD_OVERLAY.get()) {
            return false;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) {
            return false;
        }
        try {
            Object holdingGun = Reflector.invokeStatic("com.tacz.guns.api.item.IGun", "mainHandHoldGun", player);
            if (!(holdingGun instanceof Boolean) || !((Boolean) holdingGun)) {
                return false;
            }
            Object operator = Reflector.invokeStatic("com.tacz.guns.api.entity.IGunOperator", "fromLivingEntity", player);
            Object reloadState = Reflector.invokeCompatible(operator, "getSynReloadState");
            Object stateType = Reflector.invokeCompatible(reloadState, "getStateType");
            Object reloading = Reflector.invokeCompatible(stateType, "isReloading");
            return reloading instanceof Boolean && (Boolean) reloading;
        } catch (ReflectiveOperationException exception) {
            debug("TACZ reload crosshair reflection failed: " + exception.getMessage());
            return false;
        }
    }

    private static void drawMinimalCrosshair(GuiGraphics graphics, int width, int height) {
        int centerX = width / 2;
        int centerY = height / 2;
        RenderSystem.enableBlend();
        graphics.fill(centerX - 1, centerY - 6, centerX, centerY - 2, 0xB0FFFFFF);
        graphics.fill(centerX - 1, centerY + 2, centerX, centerY + 6, 0xB0FFFFFF);
        graphics.fill(centerX - 6, centerY - 1, centerX - 2, centerY, 0xB0FFFFFF);
        graphics.fill(centerX + 2, centerY - 1, centerX + 6, centerY, 0xB0FFFFFF);
    }

    public static boolean shouldThrottleWeaponUpdates() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return false;
        }
        int throttle = Math.max(1, FpsAnimPatchConfig.GENERAL_THROTTLE_IDLE_TICKS.get());
        return throttle > 1 && mc.level.getGameTime() % throttle != 0L;
    }

    public static boolean shouldThrottleSuperbVehicles(Entity vehicle) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (mc.level == null || player == null || vehicle == null) {
            return false;
        }
        if (vehicle.getRootVehicle() == player.getRootVehicle()) {
            return false;
        }
        if (player.distanceToSqr(vehicle) > square(FpsAnimPatchConfig.GENERAL_MAX_DISTANCE_VEHICLES.get())) {
            return true;
        }
        int throttle = Math.max(FpsAnimPatchConfig.GENERAL_THROTTLE_VEHICLE_TICKS.get(), FpsAnimPatchConfig.SUPERB_VEHICLE_THROTTLE_TICKS.get());
        return throttle > 1 && mc.level.getGameTime() % throttle != 0L;
    }

    private static double square(double value) {
        return value * value;
    }

    private static void debug(String message) {
        if (FpsAnimPatchConfig.GENERAL_DEBUG_LOG.get()) {
            FpsAnimPatchMod.LOGGER.info("[fps_anim_patch] {}", message);
        }
    }
}
