package com.charlesaebi.fpsanimpatch.mixin.superb;

import com.charlesaebi.fpsanimpatch.FpsAnimPatchConfig;
import com.charlesaebi.fpsanimpatch.client.FpsAnimPatchClientEvents;
import com.charlesaebi.fpsanimpatch.util.Reflector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.atsuishio.superbwarfare.item.gun.GunGeoItem", remap = false)
public abstract class SuperbGunGeoItemMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "animationPredicate", at = @At("HEAD"), cancellable = true)
    private void fpsAnimPatch$cancelReloadAnimations(CallbackInfoReturnable cir) {
        if (!FpsAnimPatchConfig.enabled() || !FpsAnimPatchConfig.SUPERB_ENABLE.get()) {
            return;
        }

        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }

        Item selfItem = (Item) (Object) this;
        ItemStack stack = player.getMainHandItem();
        if (stack.getItem() != selfItem) {
            return;
        }

        try {
            Object gunData = Reflector.invokeStatic("com.atsuishio.superbwarfare.data.gun.GunData", "from", stack);
            boolean reloading = Boolean.TRUE.equals(Reflector.invokeCompatible(gunData, "reloading"));
            if (reloading && FpsAnimPatchConfig.SUPERB_CANCEL_RELOAD_ANIMATION.get()) {
                cir.setReturnValue(stopState());
                return;
            }

            if (FpsAnimPatchConfig.SUPERB_OPTIMIZE_SHOOT.get()
                    && Boolean.TRUE.equals(Reflector.getStaticField("com.atsuishio.superbwarfare.event.ClientEventHandler", "holdingFireKey"))
                    && FpsAnimPatchClientEvents.shouldThrottleWeaponUpdates()) {
                cir.setReturnValue(stopState());
            }
        } catch (ReflectiveOperationException ignored) {
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static Object stopState() throws ReflectiveOperationException {
        Class<?> playStateClass = Reflector.findClass("software.bernie.geckolib.core.object.PlayState");
        return Enum.valueOf((Class<? extends Enum>) playStateClass.asSubclass(Enum.class), "STOP");
    }
}
