# FPS Anim Patch Source Distribution

This archive contains the corresponding source code for `fps_anim_patch`.

Contents:
- `src/`: Java sources and mod resources
- `build.gradle`, `settings.gradle`, `gradle.properties`: Gradle build configuration
- `gradlew`, `gradlew.bat`, `gradle/`: Gradle wrapper
- `LICENSE`: license notice

Build:
- Windows: `.\gradlew.bat build`
- Unix-like: `./gradlew build`

The built jar is generated in `build/libs/`.
