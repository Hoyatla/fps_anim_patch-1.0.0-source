package com.charlesaebi.fpsanimpatch.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Reflector {
    private static final Map<String, Class<?>> CLASS_CACHE = new ConcurrentHashMap<>();

    private Reflector() {
    }

    public static Class<?> findClass(String name) throws ClassNotFoundException {
        Class<?> cached = CLASS_CACHE.get(name);
        if (cached != null) {
            return cached;
        }
        Class<?> type = Class.forName(name);
        CLASS_CACHE.put(name, type);
        return type;
    }

    public static Object invokeStatic(String className, String method, Object... args) throws ReflectiveOperationException {
        return invokeCompatible(findClass(className), null, method, args);
    }

    public static Object invokeCompatible(Object target, String method, Object... args) throws ReflectiveOperationException {
        if (target == null) {
            return null;
        }
        return invokeCompatible(target.getClass(), target, method, args);
    }

    public static Object getStaticField(String className, String fieldName) throws ReflectiveOperationException {
        return getField(findClass(className), null, fieldName);
    }

    public static void setStaticField(String className, String fieldName, Object value) throws ReflectiveOperationException {
        setField(findClass(className), null, fieldName, value);
    }

    public static void setForgeConfigValue(String className, String fieldName, Object value) throws ReflectiveOperationException {
        Object configValue = getStaticField(className, fieldName);
        if (configValue != null) {
            invokeCompatible(configValue, "set", value);
        }
    }

    private static Object invokeCompatible(Class<?> type, Object owner, String methodName, Object... args) throws ReflectiveOperationException {
        Method method = findCompatibleMethod(type, methodName, args);
        if (method == null) {
            throw new NoSuchMethodException(type.getName() + "#" + methodName);
        }
        method.setAccessible(true);
        return method.invoke(owner, args);
    }

    private static Method findCompatibleMethod(Class<?> type, String methodName, Object... args) {
        for (Method method : type.getMethods()) {
            if (matches(method, methodName, args)) {
                return method;
            }
        }
        for (Method method : type.getDeclaredMethods()) {
            if (matches(method, methodName, args)) {
                return method;
            }
        }
        Class<?> superClass = type.getSuperclass();
        if (superClass != null && superClass != Object.class) {
            return findCompatibleMethod(superClass, methodName, args);
        }
        return null;
    }

    private static boolean matches(Method method, String methodName, Object... args) {
        if (!method.getName().equals(methodName)) {
            return false;
        }
        Class<?>[] parameters = method.getParameterTypes();
        if (parameters.length != args.length) {
            return false;
        }
        for (int i = 0; i < parameters.length; i++) {
            if (!isAssignable(parameters[i], args[i])) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAssignable(Class<?> parameterType, Object arg) {
        if (arg == null) {
            return !parameterType.isPrimitive();
        }
        Class<?> valueType = arg.getClass();
        if (parameterType.isPrimitive()) {
            parameterType = wrap(parameterType);
        }
        return parameterType.isAssignableFrom(valueType);
    }

    private static Class<?> wrap(Class<?> primitive) {
        if (primitive == boolean.class) {
            return Boolean.class;
        }
        if (primitive == byte.class) {
            return Byte.class;
        }
        if (primitive == short.class) {
            return Short.class;
        }
        if (primitive == int.class) {
            return Integer.class;
        }
        if (primitive == long.class) {
            return Long.class;
        }
        if (primitive == float.class) {
            return Float.class;
        }
        if (primitive == double.class) {
            return Double.class;
        }
        if (primitive == char.class) {
            return Character.class;
        }
        return primitive;
    }

    private static Object getField(Class<?> type, Object owner, String fieldName) throws ReflectiveOperationException {
        Field field = findField(type, fieldName);
        if (field == null) {
            throw new NoSuchFieldException(type.getName() + "#" + fieldName);
        }
        field.setAccessible(true);
        return field.get(owner);
    }

    private static void setField(Class<?> type, Object owner, String fieldName, Object value) throws ReflectiveOperationException {
        Field field = findField(type, fieldName);
        if (field == null) {
            throw new NoSuchFieldException(type.getName() + "#" + fieldName);
        }
        field.setAccessible(true);
        field.set(owner, value);
    }

    private static Field findField(Class<?> type, String fieldName) {
        try {
            return type.getField(fieldName);
        } catch (NoSuchFieldException ignored) {
        }
        try {
            return type.getDeclaredField(fieldName);
        } catch (NoSuchFieldException ignored) {
        }
        Class<?> superClass = type.getSuperclass();
        if (superClass != null && superClass != Object.class) {
            return findField(superClass, fieldName);
        }
        return null;
    }
}
