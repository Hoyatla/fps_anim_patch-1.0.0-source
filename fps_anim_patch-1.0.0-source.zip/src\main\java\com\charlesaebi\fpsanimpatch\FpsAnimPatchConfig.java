package com.charlesaebi.fpsanimpatch;

import net.minecraftforge.common.ForgeConfigSpec;

public final class FpsAnimPatchConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue GENERAL_ENABLE;
    public static final ForgeConfigSpec.BooleanValue GENERAL_DEBUG_LOG;
    public static final ForgeConfigSpec.IntValue GENERAL_MAX_DISTANCE_WEAPONS;
    public static final ForgeConfigSpec.IntValue GENERAL_MAX_DISTANCE_VEHICLES;
    public static final ForgeConfigSpec.IntValue GENERAL_THROTTLE_IDLE_TICKS;
    public static final ForgeConfigSpec.IntValue GENERAL_THROTTLE_VEHICLE_TICKS;

    public static final ForgeConfigSpec.BooleanValue TACZ_ENABLE;
    public static final ForgeConfigSpec.BooleanValue TACZ_INSTANT_DRAW;
    public static final ForgeConfigSpec.BooleanValue TACZ_CANCEL_RELOAD_ANIMATION;
    public static final ForgeConfigSpec.BooleanValue TACZ_HIDE_RELOAD_OVERLAY;
    public static final ForgeConfigSpec.BooleanValue TACZ_OPTIMIZE_SHOOT;
    public static final ForgeConfigSpec.IntValue TACZ_SHOOT_THROTTLE_TICKS;
    public static final ForgeConfigSpec.BooleanValue TACZ_FORCE_LOW_DETAIL;
    public static final ForgeConfigSpec.BooleanValue TACZ_REDUCE_LASER_EFFECTS;

    public static final ForgeConfigSpec.BooleanValue SUPERB_ENABLE;
    public static final ForgeConfigSpec.BooleanValue SUPERB_INSTANT_DRAW;
    public static final ForgeConfigSpec.BooleanValue SUPERB_CANCEL_RELOAD_ANIMATION;
    public static final ForgeConfigSpec.BooleanValue SUPERB_HIDE_RELOAD_OVERLAY;
    public static final ForgeConfigSpec.BooleanValue SUPERB_OPTIMIZE_SHOOT;
    public static final ForgeConfigSpec.BooleanValue SUPERB_VEHICLE_CULLING;
    public static final ForgeConfigSpec.IntValue SUPERB_VEHICLE_THROTTLE_TICKS;
    public static final ForgeConfigSpec.BooleanValue SUPERB_FORCE_GUN_LOD;
    public static final ForgeConfigSpec.BooleanValue SUPERB_REDUCE_SCREEN_SHAKE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("general");
        GENERAL_ENABLE = builder.comment("Master switch for the patch.")
                .define("enable", true);
        GENERAL_DEBUG_LOG = builder.comment("Log compatibility decisions and reflection failures.")
                .define("debugLog", false);
        GENERAL_MAX_DISTANCE_WEAPONS = builder.comment("Beyond this range, expensive weapon visuals may be simplified.")
                .defineInRange("maxDistanceWeapons", 48, 0, 256);
        GENERAL_MAX_DISTANCE_VEHICLES = builder.comment("Beyond this range, far vehicles can be culled or animation-throttled.")
                .defineInRange("maxDistanceVehicles", 160, 0, 512);
        GENERAL_THROTTLE_IDLE_TICKS = builder.comment("Run light idle animation updates once every N ticks where possible.")
                .defineInRange("throttleIdleTicks", 2, 1, 20);
        GENERAL_THROTTLE_VEHICLE_TICKS = builder.comment("Fallback global vehicle animation throttle.")
                .defineInRange("throttleVehicleTicks", 2, 1, 20);
        builder.pop();

        builder.push("tacz");
        TACZ_ENABLE = builder.define("enable", true);
        TACZ_INSTANT_DRAW = builder.define("instantDraw", true);
        TACZ_CANCEL_RELOAD_ANIMATION = builder.define("cancelReloadAnimation", true);
        TACZ_HIDE_RELOAD_OVERLAY = builder.define("hideReloadOverlay", true);
        TACZ_OPTIMIZE_SHOOT = builder.define("optimizeShoot", true);
        TACZ_SHOOT_THROTTLE_TICKS = builder.defineInRange("shootThrottleTicks", 2, 1, 10);
        TACZ_FORCE_LOW_DETAIL = builder.comment("Force TACZ low-detail item rendering where the mod exposes it.")
                .define("forceLowDetail", true);
        TACZ_REDUCE_LASER_EFFECTS = builder.comment("Trim laser fade and similar expensive first-person effects.")
                .define("reduceLaserEffects", true);
        builder.pop();

        builder.push("superbwarfare");
        SUPERB_ENABLE = builder.define("enable", true);
        SUPERB_INSTANT_DRAW = builder.define("instantDraw", true);
        SUPERB_CANCEL_RELOAD_ANIMATION = builder.define("cancelReloadAnimation", true);
        SUPERB_HIDE_RELOAD_OVERLAY = builder.define("hideReloadOverlay", true);
        SUPERB_OPTIMIZE_SHOOT = builder.define("optimizeShoot", true);
        SUPERB_VEHICLE_CULLING = builder.define("vehicleCulling", true);
        SUPERB_VEHICLE_THROTTLE_TICKS = builder.defineInRange("vehicleThrottleTicks", 2, 1, 20);
        SUPERB_FORCE_GUN_LOD = builder.comment("Enable SuperbWarfare gun LOD automatically.")
                .define("forceGunLod", true);
        SUPERB_REDUCE_SCREEN_SHAKE = builder.comment("Clamp SuperbWarfare camera and screen shake effects.")
                .define("reduceScreenShake", true);
        builder.pop();

        SPEC = builder.build();
    }

    private FpsAnimPatchConfig() {
    }

    public static boolean enabled() {
        return GENERAL_ENABLE.get();
    }
}
